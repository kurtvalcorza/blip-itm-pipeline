"""Review probes for tutorials/blip_itm_colab.ipynb (prefix ITM), Notebook Review Framework v1.

Reviewed revision: kurtvalcorza/blip-itm-pipeline main a25fdf6d2e1c8b5109300185ad21dac2e57c9723
(notebook blob 6f1e02a3380e36cd2452e25470287349973cfac9).

Environment (direct execution, CPU only): Windows, CPython 3.12, an existing venv holding the notebook's exact
pins with CPU torch (torch 2.14.0+cpu, transformers 4.57.6, safetensors 0.8.0, numpy 2.5.3, pillow 11.3.0,
huggingface-hub 0.36.2, pyarrow 25.0.1). No installs (DIMER_NOTEBOOK_CI_PREINSTALLED=1 skips cell 3's pip).
The real weights and the pinned VizWiz cache are hard-linked into a scratch working directory (not a clean
runtime; nothing is downloaded, HF_HUB_OFFLINE=1). Every code cell is executed VERBATIM from the notebook JSON
in one module namespace; only form-field literals are substituted (as an executor sets fields) and
google.colab.files.upload is replaced by a fake for BYOD. BYOD images are generated stand-ins (flat coloured
shapes drawn with Pillow), labelled as such.

Usage: python run_probes.py <notebook.ipynb> <workdir> <results.json> [probe ...]
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

NB_PATH, WORKDIR, RESULTS = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve()
SELECTED = sys.argv[4:] or ["P0", "P4", "P1", "P2", "P3", "P5"]  # P6 is run separately (needs P6_ARTIFACT)
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

NB = json.loads(NB_PATH.read_text(encoding="utf-8"))
CELLS = ["".join(c["source"]) for c in NB["cells"]]
results: dict = json.loads(RESULTS.read_text(encoding="utf-8")) if RESULTS.is_file() else {}


def save() -> None:  # write-immediately
    RESULTS.write_text(json.dumps(results, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


def set_fields(src: str, **fields) -> str:
    for name, value in fields.items():
        pattern = re.compile(rf"^{name} = .*?(  # @param.*)$", re.M)
        if not pattern.search(src):
            raise KeyError(f"form field {name} not found")  # EXE6: fail on a missing field
        src = pattern.sub(lambda m: f"{name} = {value!r}{m.group(1)}", src)
    return src


# ---- fake google.colab upload ------------------------------------------------------------------------
UPLOADS: list[dict] = []
colab = types.ModuleType("google.colab")
files_mod = types.SimpleNamespace(upload=lambda: UPLOADS.pop(0) if UPLOADS else {})
colab.files = files_mod
google = types.ModuleType("google")
google.colab = colab
sys.modules["google"] = google
sys.modules["google.colab"] = colab

NBMOD = types.ModuleType("__nb__")
sys.modules["__nb__"] = NBMOD
NS = NBMOD.__dict__


class Capture(io.StringIO):
    pass


def run_cell(index: int, src: str | None = None, *, tail: int = 4000) -> dict:
    src = CELLS[index] if src is None else src
    out = Capture()
    old = sys.stdout
    sys.stdout = out
    started = time.perf_counter()
    status, error = "ok", None
    try:
        exec(compile(src, f"<cell {index}>", "exec"), NS)
    except BaseException as exc:  # noqa: BLE001
        status = "error"
        error = f"{type(exc).__name__}: {exc}"[:1500]
    finally:
        sys.stdout = old
    text = out.getvalue()
    return {"cell": index, "status": status, "error": error, "seconds": round(time.perf_counter() - started, 1),
            "stdout_tail": text[-tail:]}


CODE = [i for i, c in enumerate(NB["cells"]) if c["cell_type"] == "code"]

# ---- P0 static ---------------------------------------------------------------------------------------
if "P0" in SELECTED:
    raw = NB_PATH.read_bytes()
    blob = hashlib.sha1(b"blob %d\0" % len(raw) + raw).hexdigest()
    compiled = {}
    for i in CODE:
        try:
            compile(CELLS[i], f"<cell {i}>", "exec")
            compiled[i] = "ok"
        except SyntaxError as exc:
            compiled[i] = str(exc)
    md = "\n".join(CELLS[i] for i, c in enumerate(NB["cells"]) if c["cell_type"] == "markdown")
    markers = {m: len(re.findall(m, md, re.I)) for m in [
        "How to use", "Roadmap", "Glossary", "Predict", "Check your", "Troubleshoot", "Infrastructure",
        "What to notice", "Expected result", "Look for", "Conclusion", "intended learner|audience", "Exercise",
        "rerun|re-run"]}
    carried = {i: len(CELLS[i].splitlines()) for i in CODE if NB["cells"][i].get("metadata", {}).get("dimer", {}).get("embedded_module")}
    results["P0_static"] = {
        "nbformat": [NB["nbformat"], NB["nbformat_minor"]], "cells": len(NB["cells"]), "code_cells": len(CODE),
        "git_blob_sha1": blob, "compile": compiled, "metadata_dimer": NB["metadata"].get("dimer"),
        "markdown_markers": markers, "carried_module_lines": carried,
        "cellView_form": sum(1 for c in NB["cells"] if c.get("metadata", {}).get("cellView") == "form"),
        "doubled_braces": {i: re.findall(r"\{\{[^}]*\}\}", CELLS[i]) for i in range(len(CELLS)) if NB["cells"][i]["cell_type"] == "markdown" and "{{" in CELLS[i]},
        "asserts_in_learner_cells": {i: [l.strip() for l in CELLS[i].splitlines() if l.strip().startswith("assert ")] for i in CODE if i not in carried},
        "outputs_persisted": sum(len(c.get("outputs", [])) for c in NB["cells"] if c["cell_type"] == "code"),
    }
    save()

os.chdir(WORKDIR)
Path("outputs").mkdir(exist_ok=True)


def make_image(kind: int, size=(96, 72)):
    from PIL import Image, ImageDraw
    colours = [("red", (220, 30, 30)), ("blue", (30, 60, 220)), ("green", (30, 160, 60)), ("yellow", (240, 210, 30))]
    shapes = ["square", "circle"]
    cname, rgb = colours[kind % 4]
    shape = shapes[(kind // 4) % 2]
    img = Image.new("RGB", size, (250, 250, 250))
    d = ImageDraw.Draw(img)
    box = [20 + kind % 7, 12 + kind % 5, 70 + kind % 7, 60 + kind % 5]
    (d.rectangle if shape == "square" else d.ellipse)(box, fill=rgb)
    return img, f"a {cname} {shape} on a white background", f"a simple drawing of a {cname} {shape}"


def jpeg_bytes(img) -> bytes:
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=90)
    return buf.getvalue()


def byod_zip(n: int, *, folder: str = "", records_name: str = "records.jsonl", ref_prefix: str = "",
             duplicate_basenames: bool = False, include_records: bool = True, prefix_id: str = "r") -> bytes:
    buf = io.BytesIO()
    recs = []
    with zipfile.ZipFile(buf, "w") as z:
        for k in range(n):
            img, c1, c2 = make_image(k)
            sub = folder
            if duplicate_basenames:
                sub = f"set{k % 2}/"
                name = f"img_{k // 2:03d}.jpg"
            else:
                name = f"img_{k:03d}.jpg"
            z.writestr(sub + name, jpeg_bytes(img))
            recs.append({"id": f"{prefix_id}{k:03d}", "image": (sub if (ref_prefix or duplicate_basenames) else "") + name, "captions": [c1, c2]})
        if include_records:
            body = "\n".join(json.dumps(r) for r in recs) if records_name.endswith(".jsonl") else json.dumps(recs)
            z.writestr(folder + records_name, body)
    return buf.getvalue()


def run_byod_section4(payload_name: str, payload: bytes | None) -> dict:
    UPLOADS.clear()
    UPLOADS.append({} if payload is None else {payload_name: payload})
    res = run_cell(13, set_fields(CELLS[13], USE_BYOD=True))
    if res["status"] == "ok":
        res["splits"] = NS.get("disjoint")
        res["data_source"] = NS.get("data_source")
    return res


# ---- P4 BYOD Section 4 only (no model; cells 3,5,7,9 define the helpers) --------------------------------
if "P4" in SELECTED:
    base = {}
    for i in (3, 5, 7, 9):
        base[i] = run_cell(i, tail=300)
    p4 = {"setup": base}
    import shutil
    def fresh():
        shutil.rmtree(WORKDIR / "work" / "byod", ignore_errors=True)
    for n in (8, 12, 20, 40, 49, 50, 60):
        fresh()
        p4[f"N{n}"] = run_byod_section4(f"n{n}.zip", byod_zip(n))
        save()
    # smallest N passing Section 4 (direct API mirroring cell 13, not the notebook cell)
    from PIL import Image
    tmp = WORKDIR / "work" / "minprobe"
    tmp.mkdir(parents=True, exist_ok=True)
    recs = []
    for k in range(80):
        img, c1, c2 = make_image(k)
        img.save(tmp / f"m{k:03d}.jpg")
        recs.append({"id": f"m{k:03d}", "image": f"m{k:03d}.jpg", "captions": [c1, c2]})
    smallest = None
    first_errors = {}
    for n in range(8, 81):
        try:
            sp = NS["split_dataset"](recs[:n], seed=42, base_dir=tmp)
            for name, part in sp.items():
                NS["validate_dataset"](part)
            smallest = n
            break
        except ValueError as exc:
            msg = str(exc)
            first_errors.setdefault(msg.split(";")[0][:40], (n, msg))
    p4["smallest_N_passing_section4_direct_api"] = smallest
    p4["error_messages_below_minimum"] = first_errors
    fresh()
    p4["subfolder_refs"] = run_byod_section4("sub.zip", byod_zip(60, folder="photos/", ref_prefix="photos/"))
    fresh()
    r = run_byod_section4("dup.zip", byod_zip(60, duplicate_basenames=True))
    if r["status"] == "ok":
        recs_ = [x for part in NS["splits"].values() for x in part]
        by_path = {}
        for x in recs_:
            by_path.setdefault(x["image"], []).append(x["id"])
        r["records"] = len(recs_)
        r["distinct_image_files"] = len(by_path)
        r["files_shared_by_two_records"] = sum(1 for v in by_path.values() if len(v) > 1)
    p4["duplicate_basenames_in_two_folders"] = r
    fresh()
    a = run_byod_section4("a.zip", byod_zip(60, prefix_id="a"))
    b = run_byod_section4("b.zip", byod_zip(60, records_name="records.json", prefix_id="b"))
    ids = [x["id"] for part in NS["splits"].values() for x in part] if b["status"] == "ok" else []
    p4["second_upload_records_json_after_jsonl"] = {"a": a["status"], "b": b, "b_data_source": NS.get("data_source"),
                                                    "ids_from_upload_a": sum(i.startswith("a") for i in ids),
                                                    "ids_from_upload_b": sum(i.startswith("b") for i in ids)}
    fresh()
    p4["cancelled_upload"] = run_byod_section4("x.zip", None)
    fresh()
    p4["zip_without_records_file"] = run_byod_section4("norec.zip", byod_zip(60, include_records=False))
    fresh()
    bad = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(byod_zip(60)), "r") as src, zipfile.ZipFile(bad, "w") as dst:
        for m in src.infolist():
            data = src.read(m)
            if m.filename == "records.jsonl":
                lines = data.decode().splitlines()
                first = json.loads(lines[0]); first["captions"] = [""]
                lines[0] = json.dumps(first)
                data = "\n".join(lines).encode()
            dst.writestr(m, data)
    p4["empty_caption_rejection"] = run_byod_section4("bad.zip", bad.getvalue())
    results["P4_byod_section4"] = p4
    save()
    fresh()

# ---- P1 default path, all code cells verbatim --------------------------------------------------------
if "P1" in SELECTED:
    p1 = {"cells": []}
    results["P1_default"] = p1
    for i in CODE:
        res = run_cell(i)
        p1["cells"].append(res)
        save()
        if res["status"] != "ok":
            break
    if all(c["status"] == "ok" for c in p1["cells"]):
        p1["comparison"] = NS["comparison"]
        p1["history"] = [{k: v for k, v in h.items()} for h in NS["adapt_result"]["history"]]
        p1["best_epoch"] = NS["adapt_result"]["best_epoch"]
        p1["parity"] = NS["parity"]
        p1["outputs"] = sorted(os.listdir("outputs"))
        p1["frozen_scene_itm"] = NS["result"]["itm_probability"].round(3).tolist()
        p1["adapted_scene_itm"] = NS["adapted_result"]["itm_probability"].round(3).tolist()
        p1["frozen_val_rsum_epoch0"] = NS["adapt_result"]["history"][0]["val"]["rsum"]
        p1["adapted_val_rsum"] = NS["adapted_val"]["rsum"]
        p1["frozen_test_rsum"] = NS["frozen_test"]["rsum"]
        p1["adapted_test_rsum"] = NS["adapted_test"]["rsum"]
    save()

# ---- P2 learner reruns Section 7 with a new field value, no reload (stale model state) ------------------
if "P2" in SELECTED and results.get("P1_default", {}).get("best_epoch") is not None:
    p2 = {"what": "after P1, set TRAINABLE_TEXT_LAYERS=4, LEARNING_RATE=5e-5 (the documented optional experiment), EPOCHS=1 and rerun Section 7 (cell 19) then Section 8 (cell 21) without rerunning Section 3"}
    res = run_cell(19, set_fields(CELLS[19], TRAINABLE_TEXT_LAYERS=4, LEARNING_RATE=5e-5, EPOCHS=1))
    p2["cell19"] = res
    if res["status"] == "ok":
        h = NS["adapt_result"]["history"]
        p2["epoch0_note"] = h[0].get("note")
        p2["history"] = h
        p2["epoch0_val_rsum"] = h[0]["val"]["rsum"]
        p2["true_frozen_val_rsum_from_P1"] = results["P1_default"]["frozen_val_rsum_epoch0"]
        p2["P1_adapted_val_rsum"] = results["P1_default"]["adapted_val_rsum"]
        p2["best_epoch"] = NS["adapt_result"]["best_epoch"]
    res21 = run_cell(21)
    p2["cell21"] = res21
    if "comparison" in NS:
        p2["comparison_after"] = NS["comparison"]
    results["P2_stale_rerun"] = p2
    save()

# ---- P3 an in-range field change that does not improve validation, from a freshly reloaded base ---------
if "P3" in SELECTED and results.get("P1_default", {}).get("best_epoch") is not None:
    p3 = {"what": "rerun Section 3 (fresh base), then Section 7 with LEARNING_RATE=1e-3 (the top of adapt's accepted range), EPOCHS=1, then Section 8"}
    before = sorted(os.listdir("outputs"))
    rep = Path("outputs/blip_itm_evaluation_report.json")
    rep_mtime = rep.stat().st_mtime if rep.exists() else None
    p3["cell11"] = run_cell(11, tail=600)
    res = run_cell(19, set_fields(CELLS[19], LEARNING_RATE=1e-3, EPOCHS=1))
    p3["cell19"] = res
    if res["status"] == "ok":
        p3["history"] = NS["adapt_result"]["history"]
        p3["best_epoch"] = NS["adapt_result"]["best_epoch"]
    save()
    res21 = run_cell(21)
    p3["cell21"] = res21
    p3["evaluation_report_rewritten"] = rep.exists() and rep.stat().st_mtime != rep_mtime
    if "adapted_test" in NS:
        p3["adapted_test_rsum"] = NS["adapted_test"]["rsum"]
        p3["frozen_test_rsum"] = NS["frozen_test"]["rsum"]
    p3["note"] = "Run all stops at the first failing cell; Section 9 (export, reload, result.json) would not run"
    results["P3_lr_experiment"] = p3
    save()

# ---- P5 BYOD positive through every downstream cell (stand-in images) ---------------------------------
if "P5" in SELECTED:
    import shutil
    shutil.rmtree(WORKDIR / "work" / "byod", ignore_errors=True)
    p5 = {"what": "fresh base (cell 11), BYOD zip of 60 stand-in drawings x 2 captions through cells 13..23 at default fields"}
    if "pipe" not in NS:
        for i in (3, 5, 7, 9):
            run_cell(i, tail=200)
    for stale_key in ("baseline_chance", "baseline_neighbour", "frozen_test", "adapted_test", "comparison", "parity"):
        NS.pop(stale_key, None)
    p5["cell11"] = run_cell(11, tail=400)
    p5["cell13"] = run_byod_section4("shapes.zip", byod_zip(60))
    p5["cells"] = []
    if p5["cell13"]["status"] == "ok":
        for i in (15, 17, 19, 21, 23):
            res = run_cell(i)
            p5["cells"].append(res)
            save()
            if res["status"] != "ok":
                break
    for key in ("baseline_chance", "baseline_neighbour", "frozen_test", "adapted_test"):
        if key in NS and isinstance(NS[key], dict):
            p5[key + "_rsum"] = NS[key].get("rsum")
    if "adapt_result" in NS:
        p5["best_epoch"] = NS["adapt_result"]["best_epoch"]
        p5["history"] = NS["adapt_result"]["history"]
    if "result_payload" in NS:
        p5["result_json_corpus_block"] = NS["result_payload"].get("corpus", {}).get("name")
        p5["result_json_data_source"] = NS["result_payload"].get("data_source")
    results["P5_byod_downstream"] = p5
    save()

# ---- P6 documented experiment RERANK_TOP_K=10 rerun after a completed run (separate process) ---------------
# The post-run state is reconstructed from P1's exported adapter (copied aside before P5 overwrote it):
# cells 3..15 verbatim, then `pipe` = BlipItmPipeline.from_artifact(P1 adapter) and `adapt_result` =
# pipe.adapter, i.e. exactly what Section 9 shows the in-memory model to be (reload parity 64/64 in P1).
# Then the learner's rerun: Section 6 (cell 17) with RERANK_TOP_K=10, then Section 8 (cell 21).
if "P6" in SELECTED:
    p6 = {"what": "post-run state from P1's adapter; set RERANK_TOP_K=10, rerun Section 6 (cell 17) then Section 8 (cell 21)"}
    p6["setup"] = {i: run_cell(i, tail=300)["status"] for i in (3, 5, 7, 9, 11, 13, 15)}
    NS["pipe"] = NS["BlipItmPipeline"].from_artifact(Path(os.environ["P6_ARTIFACT"]), weights_dir=NS["WEIGHTS_DIR"])
    NS["adapt_result"] = dict(NS["pipe"].adapter)
    NS["adapt_seconds"] = 0.0
    p6["adapter_best_epoch"] = NS["adapt_result"]["best_epoch"]
    p6["cell17"] = run_cell(17, set_fields(CELLS[17], RERANK_TOP_K=10))
    if "frozen_test" in NS:
        p6["frozen_test_rsum_as_printed"] = NS["frozen_test"]["rsum"]
        p6["frozen_test_adapted_flag"] = NS["frozen_test"].get("adapted")
    save()
    p6["cell21"] = run_cell(21)
    if "adapted_test" in NS:
        p6["adapted_test_rsum"] = NS["adapted_test"]["rsum"]
    results["P6_rerank_rerun"] = p6
    save()

print("done", sorted(results))
